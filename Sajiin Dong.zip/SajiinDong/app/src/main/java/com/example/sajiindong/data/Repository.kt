package com.example.sajiindong.data

import com.example.sajiindong.api.ApiService

class Repository(private val apiService: ApiService) {
}
