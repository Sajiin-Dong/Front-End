package com.example.sajiindong.ui.register

import androidx.lifecycle.ViewModel
import com.example.sajiindong.data.Repository

class RegisterViewModel(private val storyRepository: Repository): ViewModel() {
}