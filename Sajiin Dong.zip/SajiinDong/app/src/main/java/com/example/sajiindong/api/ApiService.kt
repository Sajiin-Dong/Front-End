package com.example.sajiindong.api

interface ApiService {

}
