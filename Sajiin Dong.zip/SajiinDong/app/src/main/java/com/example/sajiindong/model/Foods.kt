package com.example.sajiindong.model

data class Foods(
    var name: String = "",
    var diet: String = "",
    var photo: Int = 0,
    var description: String = ""
)