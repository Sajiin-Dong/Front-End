package com.example.sajiindong.ui.home

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.sajiindong.R
import com.example.sajiindong.adapter.DietFoodAdapter
import com.example.sajiindong.data.FoodsData
import com.example.sajiindong.model.Foods

@Suppress("DEPRECATION")
class HomeFragment : Fragment() {

    private lateinit var rvTeams: RecyclerView
    private var list: ArrayList<Foods> = arrayListOf()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        rvTeams = view.findViewById(R.id.rv_teams)
        rvTeams.setHasFixedSize(true)

        list.addAll(FoodsData.listData)
        showRecyclerList(view)

        return view
    }

    private fun showRecyclerList(view: View) {
        rvTeams.layoutManager = LinearLayoutManager(view.context)
        val listTeamAdapter = DietFoodAdapter(list)
        rvTeams.adapter = listTeamAdapter
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        setHasOptionsMenu(true)
    }
}
