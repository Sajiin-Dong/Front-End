package com.example.sajiindong.ui.login

import androidx.lifecycle.ViewModel
import com.example.sajiindong.data.Repository

class LoginViewModel(private val repository: Repository) : ViewModel() {
}